# Quiniela Mundial 2026 — Publicación

## 1. Supabase (5 min)
1. https://supabase.com -> New project (o usá uno existente).
2. SQL Editor -> New query -> pegá el contenido de `setup_supabase.sql` -> Run.
3. Settings -> API -> copiá **Project URL** y **anon public key**.

## 2. Configurar el HTML (1 min)
Abrí `index.html` en VSCode y editá las dos líneas del bloque CONFIGURACION
(arriba del todo) con tu URL y tu anon key.

## 3. Publicar en GitHub Pages (5 min)
1. GitHub Desktop -> New repository (ej. `quiniela-2026`) -> agregá `index.html` -> Commit -> Publish (público).
2. En github.com: repo -> Settings -> Pages -> Source: `Deploy from a branch` -> Branch `main` / carpeta `/ (root)` -> Save.
3. En 1-2 minutos queda en: `https://TU-USUARIO.github.io/quiniela-2026/`

Ese es el link que mandás al grupo de WhatsApp. Funciona en celular,
laptop y TV, sin cuenta de Claude ni de nada.

## Notas
- Los datos del artifact de Claude NO migran: la versión web arranca limpia
  (registrate primero para quedar como admin ⭐).
- La sesión de cada quien se guarda en su navegador (localStorage);
  los datos compartidos viven en tu tabla `q26_storage` de Supabase.
- Respaldo en cualquier momento: Supabase -> Table Editor -> q26_storage -> Export CSV.
- Si después cambiás algo en la app, me pedís el `index.html` nuevo,
  reemplazás el archivo y hacés commit: GitHub Pages se actualiza solo.
