-- ============================================================
-- QUINIELA MUNDIAL 2026 - Setup Supabase
-- Ejecutar UNA vez en: Supabase -> SQL Editor -> New query -> Run
-- ============================================================

create table if not exists public.q26_storage (
  key text primary key,
  value text not null,
  updated_at timestamptz default now()
);

alter table public.q26_storage enable row level security;

-- Acceso abierto con la anon key (quiniela entre conocidos).
-- La seguridad real es la misma del artifact: sistema de honor + contraseña en la app.
create policy "q26 lectura"      on public.q26_storage for select using (true);
create policy "q26 insercion"    on public.q26_storage for insert with check (true);
create policy "q26 actualizacion" on public.q26_storage for update using (true);
create policy "q26 borrado"      on public.q26_storage for delete using (true);
